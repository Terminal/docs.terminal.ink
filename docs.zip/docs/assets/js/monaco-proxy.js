self.MonacoEnvironment = {
    baseUrl: 'https://unpkg.com/monaco-editor@0.11.1/min/'
};
importScripts('https://unpkg.com/monaco-editor@0.11.1/min/vs/base/worker/workerMain.js');
