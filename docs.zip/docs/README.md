# docs.terminal.ink [![Build Status](https://travis-ci.org/Terminal/docs.terminal.ink.svg?branch=master)](https://travis-ci.org/Terminal/docs.terminal.ink)
Documentation for >terminal_ services, using GitHub Pages

## Testing
To test locally, run `bundle exec jekyll serve`.

You may wish to look 
[here (thanks alex)](https://github.com/AlexFlipnote/alexflipnote.github.io) for help setting this up initially.

## Licence

```
docs.terminal.ink
Copyright (C) 2018 Terminal.ink

This file is licenced under the CC-BY-SA-4.0. You should have
recieved a copy of the licence with this documentation series.
If not, please read a copy here:

https://creativecommons.org/licenses/by-sa/4.0/
```
